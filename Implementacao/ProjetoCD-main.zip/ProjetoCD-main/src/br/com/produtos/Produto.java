package br.com.produtos;

public interface Produto {
	
	double getValor();
	
}
